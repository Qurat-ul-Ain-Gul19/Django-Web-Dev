from django.db import models

# Create your models here.

#for making this class as a db table, inheriting inbuitl features of model class

class Destination(models.Model):

    name = models.CharField(max_length=100)
    img = models.ImageField(upload_to='pics')
    desc = models.TextField()




class Packages:
    id:int
    name : str
    desc  :str
    price : int











