from django.apps import AppConfig


class DestinConfig(AppConfig):
    name = 'destin'
