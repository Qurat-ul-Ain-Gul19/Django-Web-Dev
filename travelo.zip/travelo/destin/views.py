from django.shortcuts import render
from .models import Destination,Packages

# Create your views here.

def index(request):

    dest1 = Destination()  # object forming of class destination

    dest1.name = 'Malam Jabba'
    dest1.desc = 'Malam Jabba is a Hill Station in the Hindu Kush mountain range nearly 40 km from Saidu ' \
                 'Sharif in Swat Valley, KPK Province of Pakistan.'

    dest1.img = '1-1.jpg'

    dest2 = Destination()
    dest2.name = 'Swat'
    dest2.desc = 'Swat District is a district in Malakand Division of Khyber Pakhtunkhwa province in Pakistan. ' \
                 'Centred upon the upper portions of the Swat River'

    dest2.img = '1-2.jpg'

    dest3 = Destination()
    dest3.name = 'Kalam'
    dest3.desc = 'Kalam is a valley located at distance of 99 kilometres from Mingora in the northern upper reaches of karakoram'

    dest3.img = '1-3.jpg'

    dests = [dest1, dest2, dest3]

    pkg1 = Packages()
    pkg1.name = 'Silver'
    pkg1.desc = 'Ut ac odio scelerisque ante ornare commodo. Sed faucibus dui libero, in tincidunt purus pretium quis. Fusce posuere egestas enim eu viverra.'
    pkg1.price = '500$'

    pkg2 = Packages()
    pkg2.name = 'Platinum'
    pkg2.desc = 'Ut ac odio scelerisque ante ornare commodo. Sed faucibus dui libero, in tincidunt purus pretium quis.'
    pkg2.price = '1000$'

    pkg3 = Packages()
    pkg3.name = 'Gold'
    pkg3.desc = 'Ut ac odio scelerisque ante ornare commodo. Sed faucibus dui libero, in tincidunt purus pretium quis. Fusce posuere egestas enim eu viverra.'
    pkg3.price = '1500$'

    pkg4 = Packages()
    pkg4.name = 'Diamond'
    pkg4.desc = 'Ut ac odio scelerisque ante ornare commodo. Sed faucibus dui libero, in tincidunt purus pretium quis.'
    pkg4.price = '2500$'

    pkgz = [pkg1,pkg2,pkg3,pkg4]


    #dests = Destination.objects.all()

    return render(request,"destin/index.html",{'dests': dests,'Packages':pkgz})

def register(request):
    return render(request,'templates/destin/register.html')



