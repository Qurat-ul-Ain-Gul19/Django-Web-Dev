from django.shortcuts import render,redirect
#from django import urls
from django.contrib.auth.models import User
from . import urls
# Create your views here.
#def register(request):
    #if request.method == 'post':
     #   first_name = request.POST['first_name']
      #  email = request.POST['email']
       # password = request.POST['password']

        #user = User.objects.create_user(first_name=first_name,email=email,password=password)

        #user.save()
        #print('user craeted')
        #return redirect('/')

    #else:
       # return render(request,'templates/destin/register.html')

