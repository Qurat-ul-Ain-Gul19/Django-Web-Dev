from django.apps import AppConfig


class BasicappConfig(AppConfig):
    name = 'basicapp'
