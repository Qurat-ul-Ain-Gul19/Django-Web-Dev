from  django import forms
from AppTwo.models import User

class NewUserForm(forms.ModelForm):
    #first_name=
    class Meta():
        model= User
        fields = '__all__'
